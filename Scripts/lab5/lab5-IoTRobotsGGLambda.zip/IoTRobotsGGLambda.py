import json
import greengrasssdk

# Greengrass Client tanimlama
client = greengrasssdk.client('iot-data')


# Fonksiyonun tetiklenmesi Robo1 ve Robo2'den publish edilen her mesajın Subscription'a gelmesiyle olacak. 
def lambda_handler(event, context):
  
  # If the data comes from the cars
  if event['device'] in ['Robo1', 'Robo2']:
    #Lambda fonksiyonu gelen GreenGrass Core'a gelen her mesajı  AWS IoT Core'daki iot/gg/robots publish edecek
    payload=json.dumps(event)
    print('**payload**')
    print('payload')
    client.publish(topic='iot/gg/robots', payload)
  else:
    print "Hata Olustu.."
  return

